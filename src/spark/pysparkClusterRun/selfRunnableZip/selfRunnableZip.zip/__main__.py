from someModule import itWork,check
itWork()
check("ssssdd")