
def itWork():
    print("dddd")
def check(str):
    print(str)