def printIfWork(str):
    print("It's result: "+ str)